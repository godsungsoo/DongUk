--거래 날짜로 처리 하는 부분이 있어 여기서 부터는 각각 Insert하시오
--F5로 읽어 들일 시에 시간의 차이가 아예 없음.
INSERT INTO TRANSACTION VALUES(1,'02-100', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(1,'02-101', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(1,'02-102', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(2,'02-103', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(2,'02-104', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(2,'02-105', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(2,'02-106', DEFAULT, 1, ' ',1000,0,1000);
INSERT INTO TRANSACTION VALUES(2,'02-106', DEFAULT, 1, ' ',1000,0,2000);

insert into transaction values((select distinct user_no from transaction where account_no = '02-106'),'02-106',DEFAULT, 1, ' ',1000,0,3000);
commit;

insert all
into transaction values((select distinct user_no
                                from transaction
                                where account_no = '02-102'),'02-102',default,3,(select distinct user_name
                                                                                from transaction
                                                                                join bankmanager using (user_no)
                                                                                where account_no = '02-106'),0,1000,(select balance
                                                                                                                    from (select balance, trans_date, row_number() over(order by trans_date desc) as rank
                                                                                                                         from transaction
                                                                                                                        where account_no = '02-102') where rank = 1)-1000)
into transaction values((select distinct user_no
                                from transaction
                                where account_no = '02-106'),'02-106',default,3,(select distinct user_name
                                                                                from transaction
                                                                                  join bankmanager using (user_no)
                                                                                where account_no = '02-102'),1000,0,1000+(select balance
                                                                                                                         from (select balance, trans_date, row_number() over(order by trans_date desc) as rank
                                                                                                                         from transaction
                                                                                                                        where account_no = '02-106') where rank = 1))
select * from dual;

rollback;
select distinct user_name
from transaction
join bankmanager using (user_no)
where account_no = '02-106';